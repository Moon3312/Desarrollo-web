const videos = [
    {
    id: 1,
    title: "video 1"
    description: "Young and beautiful"
    embed: "https://www.youtube.com/embed/o_1aF54DO60?list=RDZFWC4SiZBao" title="Lana Del Rey - Young and Beautiful" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>"
}
 {
    id: 2,
    title: "video 2"
    description: "White Mustang"
    embed: "https://www.youtube.com/embed/F4ELqraXx-U?list=RDZFWC4SiZBao" title="Lana Del Rey - White Mustang (Official Music Video)" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>"
}
 {
    id: 3,
    title: "video 3"
    description: "Born to die"
    embed: "https://www.youtube.com/embed/Bag1gUxuU0g?list=RDZFWC4SiZBao" title="Lana Del Rey - Born To Die" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>"
}
 {
    id: 4,
    title: "video 4"
    description: "Blue Jeans"
    embed: "https://www.youtube.com/embed/JRWox-i6aAk?list=RDZFWC4SiZBao" title="Lana Del Rey - Blue Jeans" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>"
}
 {
    id: 5,
    title: "video 5"
    description: "Cinnamon Girl"
    embed: "https://www.youtube.com/embed/DCYmJDO2_IE?list=RDZFWC4SiZBao" title="Cinnamon Girl" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>"
}
{
    id: 6,
    title: "video 6"
    description: "Ultraviolence"
    embed: "https://www.youtube.com/embed/ZFWC4SiZBao?list=RDZFWC4SiZBao" title="Lana Del Rey - Ultraviolence" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>"
}
];

// Obtenemos referencias a los elementos del DOM
const videoList = document.getElementById("videoList");
const searchBar = document.getElementById("searchBar");

// Función para mostrar los videos en la página
function renderVideos(filteredVideos) {
  // Limpiamos el contenedor de videos antes de agregar nuevos
  videoList.innerHTML = "";

  // Recorremos la lista filtrada y creamos elementos HTML para cada video
  filteredVideos.forEach(video => {
    // Creamos una tarjeta para el video
    const card = document.createElement("div");
    card.className = "video-card";

    // Creamos el iframe que contiene el video
    const iframe = document.createElement("iframe");
    iframe.src = video.embed;
    iframe.allowFullscreen = true;

    // Creamos el elemento para el título del video
    const title = document.createElement("div");
    title.className = "video-title";
    title.textContent = video.title;

    // Agregamos el iframe y el título a la tarjeta
    card.appendChild(iframe);
    card.appendChild(title);

    // Agregamos la tarjeta al contenedor principal
    videoList.appendChild(card);
  });
}

// Escuchamos los cambios en la barra de búsqueda
searchBar.addEventListener("input", () => {
  const query = searchBar.value.toLowerCase();

  // Filtramos los videos que contienen el texto ingresado
  const filtered = videos.filter(video =>
    video.title.toLowerCase().includes(query)
  );

  // Volvemos a mostrar los videos filtrados
  renderVideos(filtered);
});

// Al cargar la página, mostramos todos los videos
renderVideos(videos);